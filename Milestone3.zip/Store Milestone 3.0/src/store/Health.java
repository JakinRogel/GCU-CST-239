package store;
//Health class subclass of Product
public class Health extends Product {

	//public constructor Health() 
	public Health(String name, String description, double price) {
		super(name, description, price);
	}

}
