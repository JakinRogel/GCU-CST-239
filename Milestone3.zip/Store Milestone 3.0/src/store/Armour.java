package store;
//Armour class subclass of Product
public class Armour extends Product {
	
	//Armour Constructor
	public Armour(String name, String description, double price) {
		super(name, description, price);
	}

}
