package store;

import java.util.ArrayList;
//Class Inventory
public class Inventory {
	//declare private arraylist of product objects named products
	private ArrayList<Product> products;
	//inventory constructor
	public Inventory() {
		//set products type product arraylist to new product arraylist
		products = new ArrayList<Product>();
		
	}
	//public return void addProductToInv() pass Product object
	public void addProductToInv(Product obj) {
		//add Product object to products arraylist
		products.add(obj);
	}
	//public return void removeItem() pass Product object
	public void removeItem(Product obj) {
		//for loop int i is zero through products array size increment i
		for(int i =0; i < products.size(); i++) {
			//if statmenet checks to see if the passed object equals an object in the products array
			if(obj.equals(products.get(i)))
				//remove object from products array at index i 
				products.remove(i);
		}
	}
	
	//used to get how much of each unique object class is in the products array
	//public return int pass product object
	public int invProductQuantity(Product obj) {
		
		int count = 0;
		//for each through products array
		for(Product p : products) {
			//checks to see if passed object has the same class as products array objects
			if(p.getClass() == obj.getClass()) {
				count++;
			}
		}
		
		return count;
	}
	//gets the size of products array
	public int invQuantity() {
		return products.size();
	}
	//displays the current objects in inventory array 
	public void showInv() {
		System.out.println("INVENTORY:");
		//for each through products array
		for(Product p : products) {
			//print to console objects in products array with overriden toString()
			System.out.println(p.toString());
		}
	}
	//checks to see if an object is in the products array
	public boolean checkAvailability(Product obj) {
		
		for(Product p : products) {
			//if object in products array equals object passed then...
			if(p.equals(obj)) {
		return true;
		} 
		}
		return false;
	}
	//returns the corresponding object from products array
	public Product getObject(Product obj) {
		// TODO Auto-generated method stub
		for(Product p : products) {
			//if the product object matches object in products array then return products array object match
			if(p.equals(obj)) {
				return p;
			}
		}
		return null;
	}

}
