package store;

import java.util.Scanner;

/*  Driver class version 2.1 store operations
 */
//Class Driver
public class Driver {
	//main method virtual store with 6 products
	public static void main(String[] args) {
		String input;
		char inputChar;
		//accepts input from the keyboard
		Scanner scnr = new Scanner(System.in);
		//instantiation of Inventory set to inv
		Inventory inv = new Inventory();
		//instantiation of Store class
		Store store = new Store();
		//instantiation of Cart class
		Cart cart = new Cart();
		//instantiation of Health class
		Health health1 = new Health("Vigor", "Healing Potion: Lots of health :)", 25.63);
		//add to inv array
		inv.addProductToInv(health1);
		//instantiation of Health class
		Health health2 = new Health("Stamina", "Healing Potion: Regens those legs!", 50.23);
		//add to inv array
		inv.addProductToInv(health2);
		//instantiation of Armour class
		Armour armour1 = new Armour("Dragon", "Armour: Made of Dragon Scales", 152.32);
		//add to inv array
		inv.addProductToInv(armour1);
		//instantiation of Armour class
		Armour armour2 = new Armour("Diamond", "Armour: Made with diamonds", 126.89);
		//add to inv array
		inv.addProductToInv(armour2);
		//instantiation of Weapons class
		Weapons weapon1 = new Weapons("Excaliber", "Weapon: Decimate your foes!", 75.69);
		//add to inv array
		inv.addProductToInv(weapon1);
		////instantiation of Weapons class
		Weapons weapon2 = new Weapons("Sting", "Weapon: Gollum beware!", 115.99);
		//add to inv array
		inv.addProductToInv(weapon2);
		
		//call Store openStore() pass Inventory and Cart objects
		store.openStore(inv, cart);
		//do while
		do {
			//Print string
			System.out.println();
			System.out.println("Input the name of the item you want!");
			//set input to the next entered String from System in
			input = scnr.next();
			//instantiate of Product class with input passed through constructor
			Product inputObj = new Product(input);
			//call Store purchase() pass in Inventory object, Cart object, inputobj 
			store.purchase(inv, cart, inputObj);
			//prompt user
			System.out.println("Select Y to purchase Item, select C to cancel last item, select N to finish");
			//set char inputChar to the next System in char
			inputChar= scnr.next().charAt(0);
			//returns last item from cart
			if(inputChar=='c'||inputChar=='C') {
				store.cancel(cart.getObject(inputObj), inv, cart);
			}
			//displays the inventory array
			inv.showInv();
		//loop while inputChar is y or Y
		} while(inputChar=='y'||inputChar=='Y'||inputChar=='c'||inputChar=='C');
		//displays the cart array contents
		cart.showCart();
		//prints to console cart total price
		System.out.println("Total $" + cart.getTotal(inv));
		//close scanner
		scnr.close();
	}
	
	

}
