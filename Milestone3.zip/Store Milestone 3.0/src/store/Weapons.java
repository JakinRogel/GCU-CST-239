package store;
//Weapons class subclass of Product
public class Weapons extends Product{

	//public constructor Weapons() 
	public Weapons(String name, String description, double price) {
		super(name, description, price);

	}


}
