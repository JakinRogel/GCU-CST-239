package store;


//Class Store
public class Store {

	//declare boolean set to storeOpen set to false
	boolean storeOpen = false;
	//declare char set to input

	//public return void purchase() pass int, int, object, object
	public void purchase(Inventory inv, Cart cart, Product obj) {
		cart.addProduct(obj, inv);
	}
	//public return void cancel() pass int, int, object, object
	public void cancel(Product obj, Inventory inv, Cart cart) {
		cart.remove(inv, obj);
		inv.addProductToInv(obj);
	}
	//public return void openStore()
	public void openStore(Inventory inv, Cart cart) {
			//storeOpen equals true
			storeOpen = true;
			//print String
			System.out.println("The Store is open!");
			//print String
			System.out.println("Welcome to the Conquest Outpost!");
			
			System.out.println("Check out our inventory:");
			
			inv.showInv();

	}
	//public return void closeStore()
	public void closeStore() {
			//storeOpen equals false
			storeOpen = false;
			//print String
			System.out.println("The Store is closed!");
	}
	
}


