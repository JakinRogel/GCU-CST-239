package store;

import java.util.ArrayList;
//Class Inventory
public class Inventory {
	//private static int set to quantityHealth
	private static int quantityHealth;
	//private static int set to quantityArmour
	private static int quantityArmour;
	//private static int set to quantityWeapons
	private static int quantityWeapons;
	//declare ArrayList of Product set to healthInv
	private ArrayList<Product> healthInv;
	//declare ArrayList of Product set to armourInv
	private ArrayList<Product> armourInv;
	//declare ArrayList of Product set to weaponsInv
	private ArrayList<Product> weaponsInv;
	//declare Product object set to healingPotion
	private Health healingPotion;
	//declare Product object set to cherry2
	private Health healingPotion2;
	//declare Product object set to healingPotion3
	private Health healingPotion3;
	//declare Product object set to healingPotion4
	private Health healingPotion4;
	//declare Product object set to healingPotion5
	private Health healingPotion5;
	//declare Product object set to armour1
	private Armour armour1;
	//declare Product object set to armour1
	private Armour armour2;
	//declare Product object set to armour1
	private Armour armour3;
	//declare Product object set to armour1
	private Armour armour4;
	//declare Product object set to armour1
	private Armour armour5;
	//declare Product object set to weapon1
	private Weapons weapon1;
	//declare Product object set to weapon2
	private Weapons weapon2;
	//declare Product object set to weapon3
	private Weapons weapon3;
	//declare Product object set to weapon4
	private Weapons weapon4;
	//declare Product object set to weapon5
	private Weapons weapon5;
	//public Inventory constructor 
	public Inventory() {
		//instantiate object healthInv from Arraylist of Product
		healthInv = new ArrayList<Product>();
		//instantiate object armourInv from Arraylist of Product
		armourInv = new ArrayList<Product>();
		//instantiate object weaponsInv from Arraylist of Product
		weaponsInv = new ArrayList<Product>();
		//instantiate object healingPotion from Product object
		healingPotion = new Health(1);
		//add object to arraylist
		healthInv.add(healingPotion);
		//increment quantity for object
		addQuantityHealth();
		//instantiate object cherry2 from Product object
		healingPotion2 = new Health(2);
		//add object to arraylist
		healthInv.add(healingPotion2);
		//increment quantity for object
		addQuantityHealth();
		//instantiate object healingPotion3 from Product object
		healingPotion3 = new Health(3);
		//add object to arraylist
		healthInv.add(healingPotion3);
		//increment quantity for object
		addQuantityHealth();
		//instantiate object healingPotion4 from Product object
		healingPotion4 = new Health(4);
		//add object to arraylist
		healthInv.add(healingPotion4);
		//increment quantity for object
		addQuantityHealth();
		//instantiate object healingPotion5 from Product object
		healingPotion5 = new Health(5);
		//add object to arraylist
		healthInv.add(healingPotion5);
		//increment quantity for object
		addQuantityHealth();
		//instantiate object armour1 from Product object
		armour1 = new Armour(1);
		//add object to arraylist
		armourInv.add(armour1);
		//increment quantity for object
		addQuantityArmour();
		//instantiate object armour2 from Product object
		armour2 = new Armour(2);
		//add object to arraylist
		armourInv.add(armour2);
		//increment quantity for object
		 addQuantityArmour();
		//instantiate object armour3 from Product object
		armour3 = new Armour(3);
		//add object to arraylist
		armourInv.add(armour3);
		//increment quantity for object
		 addQuantityArmour();
		//instantiate object armour4 from Product object
		armour4 = new Armour(4);
		//add object to arraylist
		armourInv.add(armour4);
		//increment quantity for object
		 addQuantityArmour();
		//instantiate object armour5 from Product object
		armour5 = new Armour(5);
		//add object to arraylist
		armourInv.add(armour5);
		//increment quantity for object
		 addQuantityArmour();
		//instantiate object weapon1 from Product object
		weapon1 = new Weapons(1);
		//add object to arraylist
		weaponsInv.add(weapon1);
		//increment quantity for object
		addQuantityWeapons();
		//instantiate object weapon2 from Product object
		weapon2 = new Weapons(2);
		//add object to arraylist
		weaponsInv.add(weapon2);
		//increment quantity for object
		addQuantityWeapons();
		//instantiate object weapon3 from Product object
		weapon3 = new Weapons(3);
		//add object to arraylist
		weaponsInv.add(weapon3);
		//increment quantity for object
		addQuantityWeapons();
		//instantiate object weapon4 from Product object
		weapon4 = new Weapons(4);
		//add object to arraylist
		weaponsInv.add(weapon4);
		//increment quantity for object
		addQuantityWeapons();
		//instantiate object weapon5 from Product object
		weapon5 = new Weapons(5);
		//add object to arraylist
		weaponsInv.add(weapon5);
		//increment quantity for object
		addQuantityWeapons();
	}
	//public return boolean checkInv() pass int
	public boolean checkInv(int productNum) {
		//switch pass productNum
		switch(productNum) {
		//case 1
		case 1:
			//if statement call getQuantity() pass int if greater than zero then...
			if(getQuantity(productNum) > 0) {
				//return true
				return true;
			} //otherwise return false
			else return false;
		//case 2
		case 2:
			//if statement call getQuantity() pass int if greater than zero then...
			if(getQuantity(productNum) > 0) {
				//return true
				return true;
			} //otherwise return false
			else return false;
		//case 3
		case 3:
			//if statement call getQuantity() pass int if greater than zero then...
			if(getQuantity(productNum) > 0) {
				//return true
				return true;
			} //otherwise return false
			else return false;
		//default
		default:
			//print String
			System.out.println("Wrong product number");
			//return false
			return false;
		}
		
	}
	//public return void subQuantity() pass int
	public void subQuantity(int productNum) {
		//switch pass int
		switch(productNum) {
		//case 1
		case 1: 
			//call subquantityHealth() 
			subQuantityHealth();
			//break
			break;
		//case 2
		case 2:
			//call subquantityArmour()
			subQuantityArmour();
			//break
			break;
		//case 3
		case 3:
			//call subquantityWeapons()
			subQuantityWeapons();
			//break
			break;
		//default
		default:
			//print String
			System.out.println("Wrong product number");
			//break
			break;
		}
	}
	//public return void addQuantity() pass int
	public void addQuantity(int productNum) {
		//switch pass int
		switch(productNum) {
		//case 1
		case 1: 
			//call addquantityHealth()
			addQuantityHealth();
			//break
			break;
		//case 2
		case 2:
			//call addquantityArmour()
			addQuantityArmour();
			//break
			break;
		//case 3
		case 3:
			//call addquantityWeapons()
			addQuantityWeapons();
			//break
			break;
		//default
		default:
			//print String
			System.out.println("Wrong product number");
			//break
			break;
		}
	}
	//public return void removeInv() pass int
	public void removeInv(int productNum) {
		//switch pass int
		switch(productNum) {
		//case 1
		case 1: 
			//call healthInv.remove() pass 0 
			healthInv.remove(0);
			//call subquantityHealth()
			subQuantityHealth();
			//break
			break;
		//case 2
		case 2:
			//call armourInv.remove() pass zero
			armourInv.remove(0);
			//call subquantityArmour()
			subQuantityArmour();
			//break
			break;
		//case 3
		case 3:
			//call weaponsInv.remove() pass zero
			weaponsInv.remove(0);
			//call subquantityWeapons()
			subQuantityWeapons();
			//break
			break;
		//default
		default:
			//print String
			System.out.println("Wrong product number");
			//break
			break;
		}
	}
	//public return void addInv() pass int, int
	public void addInv(int productNum, int id) {
		//switch pass int
		switch(productNum) {
		//case 1
		case 1: 
			//call healthInv.add() pass call getId() pass id
			healthInv.add(getId(id));
			//call addquantityHealth()
			addQuantityHealth();
			//break
			break;
		//case 2
		case 2:
			//call armourInv.add() pass call getId() pass id
			armourInv.add(getId(id));
			//call addquantityArmour
			addQuantityArmour();
			//break
			break;
		//case 3
		case 3:
			//call weaponsInv.add() pass call getId() pass id 
			weaponsInv.add(getId(id));
			//call addquantityWeapons()
			addQuantityWeapons();
			//break
			break;
		//default
		default:
			//print String
			System.out.println("Wrong product number");
			//break
			break;
		}
	}

	//Product getId() pass int
	Product getId(int id) {
		//switch pass id
		switch(id) {
		//case 1
		case 1:
			//return object
			return healingPotion;
		//case 2
		case 2:
			//return object
			return healingPotion2;
		//case 3
		case 3:
			//return object
			return healingPotion3;
		//case 4
		case 4:
			//return object
			return healingPotion4;
		//case 5
		case 5:
			//return object
			return healingPotion5;
		//case 6
		case 6:
			//return object
			return armour1;
		//case 7
		case 7:
			//return object
			return armour2;
		//case 8
		case 8:
			//return object
			return armour3;
		//case 9
		case 9:
			//return object
			return armour4;
		//case 10
		case 10:
			//return object
			return armour5;
		//case 11
		case 11:
			//return object
			return weapon1;
		//case 12
		case 12:
			//return object
			return weapon2;
		//case 13
		case 13:
			//return object
			return weapon3;
		//case 14
		case 14:
			//return object
			return weapon4;
		//case 15
		case 15:
			//return object
			return weapon5;
		//default
		default:
			//return null
			return null;
		}
	}
	//public return int getQuantity() pass int
	public int getQuantity(int productNum) {
		//switch pass int
		switch(productNum) {
		//case 1
		case 1:
			// return call getquantityHealth()
			return getQuantityHealth();
		//case 2
		case 2:
			//return call getquantityArmour()
			return getQuantityArmour();
		//case 3
		case 3:
			//return call getquantityWeapons()
			return getQuantityWeapons();
		//default
		default:
			//print String
			System.out.println("Wrong product number");
			//return -1
			return -1;
		}
	}
	//public static return int getquantityHealth()
	public static int getQuantityHealth() {
		//return int
		return quantityHealth;
	}
	//public return void addQuantity()
	public void addQuantityHealth() {
		//return int
		quantityHealth++;
	}
	//public return void subquantityHealth()
	public void subQuantityHealth() {
		//return int
		--quantityHealth;
	}
	//public static return int getquantityArmour()
	public static int getQuantityArmour() {
		//return int
		return quantityArmour;
	}
	//public return void addquantityArmour()
	public void addQuantityArmour() {
		//return int
		quantityArmour++;
	}
	//public return void subquantityArmour()
	public void subQuantityArmour() {
		//return int
		--quantityArmour;
	}
	//public static return int getquantityWeapons()
	public static int getQuantityWeapons() {
		//return int
		return quantityWeapons;
	}
	//public return void addquantityWeapons()
	public void addQuantityWeapons() {
		//return int
		quantityWeapons++;
	}
	//public return void subquantityWeapons()
	public void subQuantityWeapons() {
		//return int
		--quantityWeapons;
	}
	

	
}
