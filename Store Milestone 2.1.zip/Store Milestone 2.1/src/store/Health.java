package store;
//Health class subclass of Product
public class Health extends Product {

	//String array set to healthName populated with 5 Strings
	String[] healthName = {"Minor Healing Potion id#1", "Major Healing Potion id#2", "Well-Rested Healing Potion id#3", "Vigor Healing Potion id#4", "Full-Regeneration Healing Potion id#5"};
	//String array set to healthDescription populated with 5 Strings
	String[] healthDescription = {"heals a minor amount of health", "heals a major amount of health", "health amount equal to well rested", "health increased past maximun", "full health" };
	//public constructor Health() pass int count
	public Health(int count) {
		// TODO Auto-generated constructor stub
		//call object inherited setName function pass healthName String array with parameter count minus 1
		this.setName(healthName[count-1]);
		//call object inherited setPrice function pass count times 20
		this.setPrice(20.00 * (count));
		//call object inherited setDescription function pass healthDescription pass count minus 1
		this.setDescription(healthDescription[count-1]);
		//call object inherited setId pass count
		this.setId(count);
	}

}
