package store;
//Armour class subclass of Product
public class Armour extends Product {
	
	//String array set to armourName populated with 5 Strings
	String[] armourName = {"Light armour id#6", "Heavy armour id#7", "Obsidian armour id#8", "Diamond armour id#9", "Dragon armour id#10"};
	//String array set to armourDescription populated with 5 Strings
	String[] armourDescription = {"Made of leather", "Made of metal", "Made of obsidian", "Made of diamond", "Made of dragon"};
	//public constructor Armour() pass int count
	public Armour(int count) {
		// TODO Auto-generated constructor stub
		//call object inherited setName function pass armourName String array with parameter count minus 1
		this.setName(armourName[count-1]);
		//call object inherited setPrice function pass count times 55.78
		this.setPrice(55.78 * (count));
		//call object inherited setDescription function pass armourDescription pass count minus 1
		this.setDescription(armourDescription[count-1]);
		//call object inherited setId pass count plus 5
		this.setId(count+5);
	}

}
