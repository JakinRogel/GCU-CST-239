package store;
//Weapons class subclass of Product
public class Weapons extends Product{

	//String array set to weaponName populated with 5 Strings
	String[] weaponName = {"Dagger id#11", "Sword id#12", "Spear id#13", "Magic Staff id#14", "Nuke id#15"};
	//String array set to weaponDescription populated with 5 Strings
	String[] weaponDescription = {"A small blade", "A long blade", "A long stick with a metal head", "A staff with magic", "Absolute desolation"};
	//public constructor Weapons() pass int count
	public Weapons(int count) {
		// TODO Auto-generated constructor stub
		//call object inherited setName function pass healthName String array with parameter count minus 1
		this.setName(weaponName[count-1]);
		//call object inherited setPrice function pass count times 35.12
		this.setPrice(35.12 * (count));
		//call object inherited setDescription function pass weaponDescription pass count minus 1
		this.setDescription(weaponDescription[count-1]);
		//call object inherited setId pass count plus 10
		this.setId(count+10);
	}


}
