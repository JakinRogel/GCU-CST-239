package store;
//Class Product
public class Product {
	//private String set to name
	private String name;
	//private String set to description
	private String description;
	//private double set to price
	private double price;
	//private int set to id
	private int id;
	

	//public return String getName()
	public String getName() {
		//return String
		return name;
	}

	//public return String getDescription()
	public String getDescription() {
		//return String
		return description;
	}

	//public return double getPrice()
	public double getPrice() {
		//return double
		return price;
	}

	//public return int getId()
	public int getId() {
		//return int
		return id;
	}
	//public return void setPrice() pass double price
	public void setPrice(double price) {
		//set object price to passed price
		this.price = price;
	}
	//public return void setName() pass String name
	public void setName(String name) {
		//set object name to passed name
		this.name = name;
	}
	//public return void setDescription() pass String description
	public void setDescription(String description) {
		//set object description to passed description
		this.description = description;
	}
	//publid return void setId() pass id
	public void setId(int id) {
		//set object id to passed id
		this.id = id;
	}

}
