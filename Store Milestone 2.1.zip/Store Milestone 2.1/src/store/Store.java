package store;

import java.util.Scanner;

//Class Store
public class Store {
	Scanner scnr = new Scanner(System.in);
	//declare boolean set to storeOpen set to false
	boolean storeOpen = false;
	//declare int set to count set to zero
	private int count = 0;
	//declare int set to inputInt 
	private int inputInt;
	//declare int set to id
	private int id;
	//declare char set to inputChar
	private char inputChar;
	//public return void purchase() pass int, int, object, object
	public void purchase(int productNum, int id, Inventory inv, Cart cart) {
		//if statement pass call inv.checkInv() pass int and check storeOpen is true then...
		if(inv.checkInv(productNum) && storeOpen) {
				//switch pass int
				switch(productNum) {
				//case 1
				case 1:
					//call cart.addProduct() pass call cart.add() pass i and object
					cart.addProduct(cart.add(id, inv));
					//call inv.removeInv() pass int
					inv.removeInv(productNum);
					//break
					break;
				//case 2
				case 2:
					//call cart.addProduct() pass call cart.add() pass i+5 and object
					cart.addProduct(cart.add(id, inv));
					//call inv.removeInv() pass int
					inv.removeInv(productNum);
					//break
					break;
				//case 3
				case 3:
					//call cart.addProduct() pass call cart.add() pass i+10 and object
					cart.addProduct(cart.add(id, inv));
					//call inv.removeInv() pass int
					inv.removeInv(productNum);
					//break
					break;
				}
		  //otherwise print String
		} else System.out.println("does not compute");
	}
	//public return void cancel() pass int, int, object, object
	public void cancel(Inventory inv, Cart cart) {
		//if statement pass call cart.getItems() check if is not equal to 0
		if(!(cart.getItems()==0)) {
			System.out.println("Cancel an item? Enter item number below.");
			for (int i = 0; i < Cart.cart.size(); i++) {
				//print cart items name
				System.out.println(Cart.cart.get(i).getName() + " is in the cart!");
				}
			//set id to scanner next integer that is passed through console
			id = scnr.nextInt();
			//if int id is less than or equal to 5 then...
			if(id <= 5) {
				// set int inputInt to 1
				inputInt = 1;
			//otherwise if int id is less than or equal to 10 then...
			} else if (id <= 10) {
				//set int inputInt to 2
				inputInt = 2;
			//otherwise set int inputInt to 3
			} else {
				inputInt = 3;
			}
			//call cart.remove() pass int, int, object
			cart.remove(inputInt, id, inv);
		  //otherwise print String
		} else System.out.println("There is nothing in the cart");
	}
	//public return void openStore()
	public void openStore(Inventory inv, Cart cart) {

			//storeOpen equals true
			storeOpen = true;
			//print String
			System.out.println("The Store is open!");
			//print String
			System.out.println("Welcome to the Conquest Outpost!");
			//Print string
			System.out.println("Input H for a healing potion, A for armour, W for a weapon");
			//declare char inputChar and set equal to scanner next line character at index 0
			inputChar = scnr.next().charAt(0);
			//if the input char is h H a A w W then...
			if(inputChar=='h'||inputChar=='H'||inputChar=='a'||inputChar=='A'||inputChar=='w'||inputChar=='W') {
				//print string
				System.out.println("Input # to select item");
				//switch statment pass inputChar
				switch(inputChar) {
				//case h
				case 'h':
					//Print String
					System.out.println("#1 for Minor Healing Potion");
					//Print String
					System.out.println("#2 for Major Healing Potion");
					//Print String
					System.out.println("#3 for Well-Rested Healing Potion");
					//Print String
					System.out.println("#4 for Vigor Healing Potion");
					//Print String
					System.out.println("#5 for Full-Regeneration Healing Potion");
					//set int inputInt to next int passed through console
					inputInt = scnr.nextInt();
					//if inputInt is 1 2 3 4 5 then...
					if(inputInt==1||inputInt==2||inputInt==3||inputInt==4||inputInt==5) {
						//call purchaseMenu() parameters inputChar, inputInt, inv, cart
						purchaseMenu(inputChar,inputInt,inv,cart);
					//otherwise...
					} else {
						//Print String
						System.out.println("Wrong input");
						//Print line
						System.out.println();
						//call openStore() pass inv, cart
						openStore(inv, cart);
					}
					//break
					break;
				//case H
				case 'H':
					//Print String
					System.out.println("#1 for Minor Healing Potion");
					//Print String
					System.out.println("#2 for Major Healing Potion");
					//Print String
					System.out.println("#3 for Well-Rested Healing Potion");
					//Print String
					System.out.println("#4 for Vigor Healing Potion");
					//Print String
					System.out.println("#5 for Full-Regeneration Healing Potion");
					//set int inputInt to scanner next int through console
					inputInt = scnr.nextInt();
					//if inputInt is 1 2 3 4 5 then...
					if(inputInt==1||inputInt==2||inputInt==3||inputInt==4||inputInt==5) {
						//call purchaseMenu() pass inputChar, inputInt, inv, cart 
						purchaseMenu(inputChar,inputInt,inv,cart);
					//otherwise...
					} else {
						//Print String
						System.out.println("Wrong input");
						//Print line
						System.out.println();
						//call openStore() pass inv, cart
						openStore(inv, cart);
					}
					//break
					break;
				//case a
				case 'a':
					//Print String
					System.out.println("#6 for Light armour");
					//Print String
					System.out.println("#7 for Heavy armour");
					//Print String
					System.out.println("#8 for Obsidian armour");
					//Print String
					System.out.println("#9 for Diamond armour");
					//Print String
					System.out.println("#10 for Dragon armour");
					//set inputInt to scanner next int through console
					inputInt = scnr.nextInt();
					//if inputInt is 6 7 8 9 10 then...
					if(inputInt==6||inputInt==7||inputInt==8||inputInt==9||inputInt==10) {
						//call purchaseMenu() pass inputChar, inputInv, inv, cart
						purchaseMenu(inputChar,inputInt,inv,cart);
					//otherwise...
					} else {
						//Print String
						System.out.println("Wrong input");
						//Print line
						System.out.println();
						//call openStore() pass inv, cart
						openStore(inv, cart);
					}
					//break
					break;
				//case A
				case 'A':
					//Print String
					System.out.println("#6 for Light armour");
					//Print String
					System.out.println("#7 for Heavy armour");
					//Print String
					System.out.println("#8 for Obsidian armour");
					//Print String
					System.out.println("#9 for Diamond armour");
					//Print String
					System.out.println("#10 for Dragon armour");
					//set inputInt to scanner next int through console
					inputInt = scnr.nextInt();
					//if inputInt is 6 7 8 9 10 then...
					if(inputInt==6||inputInt==7||inputInt==8||inputInt==9||inputInt==10) {
						//call purchaseMenu() pass inputChar, inputInt, inv, cart
						purchaseMenu(inputChar,inputInt,inv,cart);
					//otherwise
					} else {
						//Print String
						System.out.println("Wrong input");
						//Print line
						System.out.println();
						//call openStore() pass inv, cart
						openStore(inv, cart);
					}
					//break
					break;
				//case w
				case 'w':
					//Print String
					System.out.println("#11 for Dagger");
					//Print String
					System.out.println("#12 for Sword");
					//Print String
					System.out.println("#13 for Spear");
					//Print String
					System.out.println("#14 for Magic Staff");
					//Print String
					System.out.println("#15 for Nuke");
					//set inputInt to scanner next int through console
					inputInt = scnr.nextInt();
					//if inputInt is 11 12 13 14 15 then...
					if(inputInt==11||inputInt==12||inputInt==13||inputInt==14||inputInt==15) {
						//call purchaseMenu() pass inputChar, inputInt, inv, cart 
						purchaseMenu(inputChar,inputInt,inv,cart);
					//otherwise...
					} else {
						//Print String
						System.out.println("Wrong input");
						//Print line
						System.out.println();
						//call openStore() pass inv, cart 
						openStore(inv, cart);
					}
					//break
					break;
				//case W
				case 'W':
					//Print String
					System.out.println("#11 for Dagger");
					//Print String
					System.out.println("#12 for Sword");
					//Print String
					System.out.println("#13 for Spear");
					//Print String
					System.out.println("#14 for Magic Staff");
					//Print String
					System.out.println("#15 for Nuke");
					//set inputInt to scanner next int through console 
					inputInt = scnr.nextInt();
					//if inputInt is 11 12 13 14 15 then... 
					if(inputInt==11||inputInt==12||inputInt==13||inputInt==14||inputInt==15) {
						//call purchaseMenu() pass inputChar, inputInt, inv, cart 
						purchaseMenu(inputChar,inputInt,inv,cart);
					//otherwise...
					} else {
						//Print String
						System.out.println("Wrong input");
						//Print line
						System.out.println();
						//call openStore() pass inv, cart 
						openStore(inv, cart);
					}
					//break
					break;
				//default
				default:
					//Print String
					System.out.println("does not compute");
					//break
					break;
				}
			//otherwise...
			} else {
				//Print String
				System.out.println("Wrong input");
				//Print line
				System.out.println();
				//call openStore() pass inv, cart
				openStore(inv, cart);
			}
			
			
	}
	//public return void closeStore()
	public void closeStore() {
			//storeOpen equals false
			storeOpen = false;
			//print String
			System.out.println("The Store is closed!");
		  //otherwise print String

	}
	public void purchaseMenu(char inputChar, int inputInt, Inventory inv, Cart cart) {
		// TODO Auto-generated method stub
		//while storeOpen is true...
		while(storeOpen) {
			//Print line
			System.out.println();
			//if int count is zero...
			if(count == 0) {
				//switch statment pass inputChar
				switch(inputChar) {
				//case h
				case 'h':
					//call purchase() pass 1, inputInt, inv, cart
					purchase(1, inputInt, inv, cart);
					//break
					break;
				//case H
				case 'H':
					//call purchase() pass 1, inputInt, inv, cart
					purchase(1, inputInt, inv, cart);
					//break
					break;
				//case a
				case 'a':
					//call purchase() pass 2, inputInt, inv, cart
					purchase(2, inputInt, inv, cart);
					//break
					break;
				//case A
				case 'A':
					//call purchase() pass 2, inputInt, inv, cart
					purchase(2, inputInt, inv, cart);
					//break
					break;
				//case w
				case 'w':
					//call purchase() pass 3, inputInt, inv, cart
					purchase(3, inputInt, inv, cart);
					//break
					break;
				//case W
				case 'W':
					//call purchase() pass 3, inputInt, inv, cart
					purchase(3, inputInt, inv, cart);
					//break
					break;
				//default
				default:
					//Print String
					System.out.println("Wrong input");
					//break
					break;
				
				}
				//for loop through cart size...
				for (int i = 0; i < Cart.cart.size(); i++) {
					//print cart items name
					System.out.println(Cart.cart.get(i).getName() + " is in the cart!");
					}
				//increment count by 1
				count++;
			}
			//Print line
			System.out.println();
			//Print String
			System.out.println("Input Y to add more items to cart and N to stop");
			//set inputChar to scanner next line character at index zero
			inputChar = scnr.next().charAt(0);
			//if inputChar is y or Y then...
			if(inputChar=='y'||inputChar=='Y') {
			//Print String
			System.out.println("Input H for a healing potion, A for armour, W for a weapon");
			//set inputChar to scanner next line character at index zero
			inputChar = scnr.next().charAt(0);
			//if inputChar is h H a A w W then...
			if(inputChar=='h'||inputChar=='H'||inputChar=='a'||inputChar=='A'||inputChar=='w'||inputChar=='W') {
				//Print String
				System.out.println("Input # to select item");
				//switch statment pass inputChar
				switch(inputChar) {
				//case h
				case 'h':
					//Print String
					System.out.println("#1 for Minor Healing Potion");
					//Print String
					System.out.println("#2 for Major Healing Potion");
					//Print String
					System.out.println("#3 for Well-Rested Healing Potion");
					//Print String
					System.out.println("#4 for Vigor Healing Potion");
					//Print String
					System.out.println("#5 for Full-Regeneration Healing Potion");
					//set inputInt to scanner next int 
					inputInt = scnr.nextInt();
					//break
					break;
				//case H
				case 'H':
					//Print String
					System.out.println("#1 for Minor Healing Potion");
					//Print String
					System.out.println("#2 for Major Healing Potion");
					//Print String
					System.out.println("#3 for Well-Rested Healing Potion");
					//Print String
					System.out.println("#4 for Vigor Healing Potion");
					//Print String
					System.out.println("#5 for Full-Regeneration Healing Potion");
					//set inputInt to scanner next int 
					inputInt = scnr.nextInt();
					//break
					break;
				//case 
				case 'a':
					//Print String
					System.out.println("#6 for Light armour");
					//Print String
					System.out.println("#7 for Heavy armour");
					//Print String
					System.out.println("#8 for Obsidian armour");
					//Print String
					System.out.println("#9 for Diamond armour");
					//Print String
					System.out.println("#10 for Dragon armour");
					//set inputInt to scanner next int
					inputInt = scnr.nextInt();
					//break
					break;
				//case A
				case 'A':
					//Print String
					System.out.println("#6 for Light armour");
					//Print String
					System.out.println("#7 for Heavy armour");
					//Print String
					System.out.println("#8 for Obsidian armour");
					//Print String
					System.out.println("#9 for Diamond armour");
					//Print String
					System.out.println("#10 for Dragon armour");
					//set inputInt to scanner next int 
					inputInt = scnr.nextInt();
					//break 
					break;
				//case w
				case 'w':
					//Print String
					System.out.println("#11 for Dagger");
					//Print String
					System.out.println("#12 for Sword");
					//Print String
					System.out.println("#13 for Spear");
					//Print String
					System.out.println("#14 for Magic Staff");
					//Print String
					System.out.println("#15 for Nuke");
					//set inputInt to scanner next int
					inputInt = scnr.nextInt();
					//break
					break;
				//case W
				case 'W':
					//Print String
					System.out.println("#11 for Dagger");
					//Print String
					System.out.println("#12 for Sword");
					//Print String
					System.out.println("#13 for Spear");
					//Print String
					System.out.println("#14 for Magic Staff");
					//Print String
					System.out.println("#15 for Nuke");
					//set inputInt to scanner next int
					inputInt = scnr.nextInt();
					//break
					break;
				//default
				default:
					//Print String
					System.out.println("does not compute");
					//break
					break;
				} 
				//if inputInt is 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 then...
				if(inputInt==1||inputInt==2||inputInt==3||inputInt==4||inputInt==5||inputInt==6||inputInt==7||inputInt==8||inputInt==9||inputInt==10||inputInt==11||inputInt==12||inputInt==13||inputInt==14||inputInt==15) {
					//switch statment pass inputChar
					switch(inputChar) {
					//case h
					case 'h':
						//call purchase() pass 1, inputInt, inv, cart 
						purchase(1, inputInt, inv, cart);
						//break
						break;
					//case H
					case 'H':
						//call purchase() pass 1, inputInt, inv, cart 
						purchase(1, inputInt, inv, cart);
						//break
						break;
					//case a
					case 'a':
						//call purchase() pass 2, inputInt, inv, cart 
						purchase(2, inputInt, inv, cart);
						//break
						break;
					//case A
					case 'A':
						//call purchase() pass 2, inputInt, inv, cart 
						purchase(2, inputInt, inv, cart);
						//break
						break;
					//case w
					case 'w':
						//call purchase() pass 3, inputInt, inv, cart 
						purchase(3, inputInt, inv, cart);
						//break
						break;
					//case W
					case 'W':
						//call purchase() pass 3, inputInt, inv, cart 
						purchase(3, inputInt, inv, cart);
						//break
						break;
					//default
					default:
						//Print String
						System.out.println("Wrong input");
						//break
						break;
					
					} 
					//for loop through cart size...
					for (int i = 0; i < Cart.cart.size(); i++) {
						//print cart items name
						System.out.println(Cart.cart.get(i).getName() + " is in the cart!");
						}
				//otherwise...
				} else {
					//Print String
					System.out.println("Wrong input");
					//Print Line
					System.out.println();
				}
			} 
			//otherwise if inputChar is n or N...
			} else if(inputChar=='n'||inputChar=='N') {
				//set storeOpen to false
				storeOpen = false;
			}
		//otherwise...
		else {
			//Print String
			System.out.println("Wrong input, try again");
		}
		}
	}
}


